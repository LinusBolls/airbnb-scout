# play midi files, on your 3D printer!

# installing

install the plugin from this url: https://github.com/linusbolls/octoplay/archive/main.zip
